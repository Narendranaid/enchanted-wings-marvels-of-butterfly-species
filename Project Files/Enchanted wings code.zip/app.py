# app.py
import os
import numpy as np
from flask import Flask, render_template, request
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.applications.vgg16 import preprocess_input
import json

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'

# Load model and class labels
model = load_model('vgg16_model.h5')
with open("class_labels.json") as f:
    class_labels = json.load(f)

def predict_image(image_path):
    image = load_img(image_path, target_size=(224, 224))
    image = img_to_array(image)
    image = np.expand_dims(image, axis=0)
    image = preprocess_input(image)
    
    prediction = model.predict(image)
    index = np.argmax(prediction)
    return class_labels[index], round(float(np.max(prediction)) * 100, 2)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/input')
def input_page():
    return render_template('input.html')

@app.route('/predict', methods=['POST'])
def predict():
    file = request.files['file']
    if file.filename == '':
        return 'No image selected'
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)
    
    predicted_class, confidence = predict_image(filepath)
    return render_template('output.html', filename=file.filename, prediction=predicted_class, confidence=confidence)

if __name__ == '__main__':
    app.run(debug=True)
